package com.TableIbnuCRUD.Table_Ibnu_CRUD.features.subject_crud;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}