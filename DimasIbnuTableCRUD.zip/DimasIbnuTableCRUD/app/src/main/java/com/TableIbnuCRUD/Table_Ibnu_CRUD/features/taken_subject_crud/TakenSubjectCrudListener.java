package com.TableIbnuCRUD.Table_Ibnu_CRUD.features.taken_subject_crud;

public interface TakenSubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdated);

    void onTakenSubjectUpdated(boolean isUpdated);
}
